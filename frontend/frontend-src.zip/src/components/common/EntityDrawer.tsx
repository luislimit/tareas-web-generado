import { Box, Button, Divider, Drawer, IconButton, Stack, Typography } from '@mui/material'
import type { ReactNode } from 'react'
import { UiGlyph } from './UiGlyph'
interface Props { open:boolean; title:string; children:ReactNode; saving?:boolean; saveLabel?:string; saveDisabled?:boolean; onClose:()=>void; onSave:()=>void }
export function EntityDrawer({open,title,children,saving=false,saveLabel='Guardar',saveDisabled=false,onClose,onSave}:Props){
 return <Drawer anchor="right" open={open} onClose={saving?undefined:onClose}><Box sx={{width:{xs:420,md:560},maxWidth:'92vw',height:'100%',display:'flex',flexDirection:'column'}}><Stack direction="row" alignItems="center" justifyContent="space-between" sx={{px:2.5,py:1.5}}><Typography variant="h6" fontWeight={700}>{title}</Typography><IconButton onClick={onClose} disabled={saving}><UiGlyph text="×" title="Cerrar" /></IconButton></Stack><Divider/><Box sx={{p:2.5,overflow:'auto',flex:1,minHeight:0,display:'flex',flexDirection:'column'}}>{children}</Box><Divider/><Stack direction="row" justifyContent="flex-end" spacing={1} sx={{p:2}}><Button onClick={onClose} disabled={saving}>Cancelar</Button><Button variant="contained" onClick={onSave} disabled={saving||saveDisabled}>{saving?'Guardando…':saveLabel}</Button></Stack></Box></Drawer>
}
